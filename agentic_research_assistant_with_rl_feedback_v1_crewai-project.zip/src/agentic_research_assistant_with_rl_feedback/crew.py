import os

from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	SerplyWebSearchTool,
	ScrapeWebsiteTool,
	FileReadTool
)





@CrewBase
class AgenticResearchAssistantWithRlFeedbackCrew:
    """AgenticResearchAssistantWithRlFeedback crew"""

    
    @agent
    def research_orchestrator(self) -> Agent:
        
        return Agent(
            config=self.agents_config["research_orchestrator"],
            
            
            tools=[				SerplyWebSearchTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def web_research_specialist(self) -> Agent:
        
        return Agent(
            config=self.agents_config["web_research_specialist"],
            
            
            tools=[				SerplyWebSearchTool(),
				ScrapeWebsiteTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def evidence_synthesizer_and_analyst(self) -> Agent:
        
        return Agent(
            config=self.agents_config["evidence_synthesizer_and_analyst"],
            
            
            tools=[				FileReadTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    
    @agent
    def technical_research_writer(self) -> Agent:
        
        return Agent(
            config=self.agents_config["technical_research_writer"],
            
            
            tools=[				FileReadTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                temperature=0.7,
            ),
            
        )
    

    
    @task
    def controller_planning_task(self) -> Task:
        return Task(
            config=self.tasks_config["controller_planning_task"],
            markdown=False,
            
            
        )
    
    @task
    def research_task(self) -> Task:
        return Task(
            config=self.tasks_config["research_task"],
            markdown=False,
            
            
        )
    
    @task
    def analysis_task(self) -> Task:
        return Task(
            config=self.tasks_config["analysis_task"],
            markdown=False,
            
            
        )
    
    @task
    def writer_task(self) -> Task:
        return Task(
            config=self.tasks_config["writer_task"],
            markdown=False,
            
            
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the AgenticResearchAssistantWithRlFeedback crew"""
        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
        )

    def _load_response_format(self, name):
        with open(os.path.join(self.base_directory, "config", f"{name}.json")) as f:
            json_schema = json.loads(f.read())

        return SchemaConverter.build(json_schema)
